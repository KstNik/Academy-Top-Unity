﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    public GameObject buttonExit;
    public GameObject buttonPlay;
    float width;
    public AudioClip Click;
    private AudioSource Speacer;
    public GameObject NameText;

    void Start()
    {
        Speacer = GetComponent<AudioSource>();

        width = Screen.height / 10;
        buttonExit.transform.GetComponent<RectTransform>().sizeDelta =
            new Vector2(width,width);
        
        buttonPlay.transform.GetComponent<RectTransform>().sizeDelta =
            new Vector2(width * 2.5f, width * 2.5f);

        NameText.transform.GetComponent<RectTransform>().sizeDelta =
            new Vector2(width * 8, width * 4);
    }

    public void ButtonEnterMouse(GameObject button) 
    {
        button.transform.GetComponent<Image>().color = Color.white;
    }

    public void ButtonExitMouse(GameObject button)
    {
        button.transform.GetComponent<Image>().color = Color.green;
    }

    public void Exit() 
    {
        Speacer.PlayOneShot(Click);
        Application.Quit();
    }

    public void Enter()
    {
        Speacer.PlayOneShot(Click);
        SceneManager.LoadScene("Game");
    }

    void Update()
    {
        
    }
}
