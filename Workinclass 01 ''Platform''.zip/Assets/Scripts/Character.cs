﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour
{
    public int direction = 0;
    private bool IsGround = false;
    float isJump = 0;

    public AudioClip jumpSong;
    public AudioClip undoSong;

    void Start() { }

    private void CheckGround()
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, 0.2f);
        IsGround = colliders.Length > 1;
    }

    void FixedUpdate() { CheckGround(); }

    public void Jump()
    {
        if (IsGround)
        {
            GetComponent<Rigidbody2D>().AddForce(
                transform.up * 5.0f,
                ForceMode2D.Impulse);
            GetComponent<CircleCollider2D>().isTrigger = true;
            isJump = 20;
            GetComponent<AudioSource>().PlayOneShot(jumpSong);
        }
        else { GetComponent<AudioSource>().PlayOneShot(undoSong); }
    }

    void Update()
    {
        if (Input.GetKeyDown("a")) { direction = -1; }
        if (Input.GetKeyDown("d")) { direction = 1; }
        if (Input.GetKeyUp("a") || Input.GetKeyUp("d")) { direction = 0; }

        if (Input.GetKeyDown("space")) { Jump(); }

        if (isJump!= 0)
        {
            isJump -= 1;
        }

        if (isJump == 0 && GetComponent<CircleCollider2D>().isTrigger == true)
        {
            GetComponent<CircleCollider2D>().isTrigger = false;
        }

        Vector3 dir = transform.right * direction;
        transform.position = Vector3.MoveTowards(
            transform.position,
            transform.position + dir,
            0.8f * Time.deltaTime);
    }
}
